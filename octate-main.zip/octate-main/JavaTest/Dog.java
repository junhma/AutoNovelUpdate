package JavaTest;

public class Dog {

    String name;

    // constructor
    public Dog(String name) {
        this.name = name;
    }

    public void setName(String newName) {
        this.name=newName;
    }
    
    


}
