package JavaTest;

public class test {
    public static void main(String arg[]) {
        
        Dog aDog = new Dog("Max"); // creating the "Max" dog
        foo(aDog);
        System.out.println(aDog.name);
    }
    
    public static void foo(Dog d) {
        d.setName("Fifi");
    }

}
