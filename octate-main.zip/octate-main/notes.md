# notes

## 7zip

7z a -mx9 -tzip -p[password] [name.zip] [filename]  *zip*  
7z x [filename]  *unzip*  
testtest

## linux shell

sudo apt purge [name]  *clean un-install*  
cd  *change directory*  
cd..  *parent directory*  
CTRL+C  *kill a process in terminal*  
unzip -O shift-jis ~/Downloads/資料.zip  *Japanese file name encoding*  
split -l 100000 file.txt *split file*

## rename

rename 's/.zip/.cbz/' \*.zip  *bulk chage file extension, zip to cbz*  
rename 's/.rar/.cbr/' \*.rar  *bulk chage file extension, zip to cbz*  
rename 's/\s+/_/g' \*     *bulk rid of spaces in file name*  
